public class Combustivel {

    public static double valorGasolina = 5.89;
    
    
}
